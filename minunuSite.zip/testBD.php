<?php
	
	
include "back/actionsbd.php";
	$customer_id="23k4jh2kljhf89";	
	insertTest($customer_id);	
	
?>